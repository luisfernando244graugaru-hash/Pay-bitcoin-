import test from 'node:test';
import assert from 'node:assert/strict';
import { deriveAddress, parseExtendedPublicKey, base58CheckDecode, base58CheckEncode, satsToBtc } from '../src/lib/bitcoin.js';

// Vetores oficiais do BIP84 (mnemônico "abandon ... about", conta 0)
const ZPUB = 'zpub6rFR7y4Q2AijBEqTUquhVz398htDFrtymD9xYYfG1m4wAcvPhXNfE3EfH1r1ADqtfSdVCToUG868RvUUkgDKf31mGDtKsAYz2oz2AGutZYs';

test('BIP84 mainnet: primeiros endereços de recebimento', () => {
  assert.equal(deriveAddress(ZPUB, 0).address, 'bc1qcr8te4kr609gcawutmrza0j4xv80jy8z306fyu');
  assert.equal(deriveAddress(ZPUB, 1).address, 'bc1qnjg0jd8228aq7egyzacy8cys3knf9xvrerkf9g');
});
test('vpub (testnet) gera o mesmo programa com prefixo tb', () => {
  const raw = base58CheckDecode(ZPUB);
  const v = Buffer.from(raw); v.writeUInt32BE(0x045F1CF6, 0);
  const a = deriveAddress(base58CheckEncode(v), 0);
  assert.equal(a.network, 'bitcoin-testnet');
  assert.ok(a.address.startsWith('tb1q'));
});
test('rejeita chave privada e tipos não suportados', () => {
  assert.throws(() => parseExtendedPublicKey('zprvAdG4iTXWBoARxkkzNpNh8r6Qag3irQB8PzEMkAFeTRXxHpbF9z4QgEvBRmfvqWvGp42t42nvgGpNgYSJA9iefm1yYNZKEm7z6qUWCroSQnE'), /private_key_rejected/);
  assert.throws(() => parseExtendedPublicKey('xpub661MyMwAqRbcFtXgS5sYJABqqG9YLmC4Q1Rdap9gSE8NqtwybGhePY2gZ29ESFjqJoCu1Rupje8YtGqsefD265TMg7usUDFdp6W1EGMcet8'), /unsupported_key_type/);
  assert.throws(() => parseExtendedPublicKey('lixo'), /invalid_extended_key/);
});
test('satsToBtc', () => {
  assert.equal(satsToBtc(1), '0.00000001');
  assert.equal(satsToBtc(150000000), '1.5');
  assert.equal(satsToBtc(100000000), '1');
  assert.equal(satsToBtc(12345), '0.00012345');
});
