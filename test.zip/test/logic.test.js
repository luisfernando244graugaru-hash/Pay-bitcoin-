import test from 'node:test';
import assert from 'node:assert/strict';
import { evaluate } from '../src/lib/status.js';
import { isPrivateIp, validateWebhookUrl } from '../src/lib/net-safety.js';
import { encryptSecret, decryptSecret } from '../src/lib/secrets.js';

const base = { amountSats: 1000n, status: 'PENDING', expired: false, total: 0n, confirmedTotal: 0n, maxConfirmations: 0 };
test('status: fluxo normal', () => {
  assert.equal(evaluate(base), 'PENDING');
  assert.equal(evaluate({ ...base, total: 1000n }), 'DETECTED');
  assert.equal(evaluate({ ...base, total: 1000n, maxConfirmations: 1 }), 'CONFIRMING');
  assert.equal(evaluate({ ...base, total: 1000n, confirmedTotal: 1000n, maxConfirmations: 1 }), 'CONFIRMED');
  assert.equal(evaluate({ ...base, total: 1500n, confirmedTotal: 1500n, maxConfirmations: 3 }), 'OVERPAID');
});
test('status: expiração e pagamento parcial', () => {
  assert.equal(evaluate({ ...base, expired: true }), 'EXPIRED');
  assert.equal(evaluate({ ...base, expired: true, total: 400n }), 'UNDERPAID');
  assert.equal(evaluate({ ...base, status: 'UNDERPAID', expired: true, total: 1000n, confirmedTotal: 1000n, maxConfirmations: 2 }), 'CONFIRMED');
  assert.equal(evaluate({ ...base, status: 'DETECTED', expired: true, total: 1000n }), 'DETECTED'); // detectado antes de expirar continua
});
test('SSRF: IPs privados bloqueados', () => {
  for (const ip of ['127.0.0.1', '10.0.0.5', '192.168.1.1', '172.16.0.1', '169.254.169.254', '100.64.0.1', '::1', 'fd00::1', 'fe80::1', '::ffff:127.0.0.1', '0.0.0.0']) assert.equal(isPrivateIp(ip), true, ip);
  for (const ip of ['8.8.8.8', '1.1.1.1', '2606:4700:4700::1111']) assert.equal(isPrivateIp(ip), false, ip);
});
test('SSRF: validação de URL de webhook', () => {
  assert.ok(validateWebhookUrl('https://example.com/hook'));
  for (const u of ['http://example.com', 'https://localhost/x', 'https://127.0.0.1/x', 'https://user:pw@example.com', 'ftp://x.com', 'nada', 'https://meta.internal/x'])
    assert.throws(() => validateWebhookUrl(u), u);
  assert.ok(validateWebhookUrl('http://localhost:9000/hook', { allowInsecure: true }));
});
test('cifra de segredos', () => {
  process.env.JWT_SECRET = 'x'.repeat(40);
  const blob = encryptSecret('whsec_abc');
  assert.equal(decryptSecret(blob), 'whsec_abc');
  assert.notEqual(encryptSecret('whsec_abc'), blob);
});
