const $ = (id) => document.getElementById(id);
const state = { token: null, user: null, merchants: [], merchantId: null, merchant: null };

function h(tag, attrs = {}, ...kids) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) { if (k === 'class') el.className = v; else if (k.startsWith('on')) el.addEventListener(k.slice(2), v); else el.setAttribute(k, v); }
  for (const kid of kids.flat()) el.append(kid instanceof Node ? kid : document.createTextNode(kid ?? ''));
  return el;
}
const say = (t, bad = false) => { const m = $('message'); m.textContent = t || ''; m.className = 'msg' + (bad ? ' bad' : ''); };
const fmtDate = (d) => (d ? new Date(d).toLocaleString('pt-BR') : '—');

async function api(path, { method = 'GET', body, headers = {} } = {}) {
  const res = await fetch('/api/v1' + path, {
    method, headers: { ...(body ? { 'Content-Type': 'application/json' } : {}), ...(state.token ? { Authorization: `Bearer ${state.token}` } : {}), ...headers },
    body: body ? JSON.stringify(body) : undefined
  });
  const data = await res.json().catch(() => ({}));
  if (res.status === 401 && state.token) { logout('Sessão expirada. Entre novamente.'); throw new Error('session_expired'); }
  if (!res.ok) throw new Error(data.error || `erro_${res.status}`);
  return data;
}
const guard = (fn) => async (...a) => { try { say(''); await fn(...a); } catch (e) { if (e.message !== 'session_expired') say(e.message, true); } };

function logout(msg = '') {
  state.token = null; state.user = null;
  $('appView').hidden = true; $('nav').hidden = true; $('merchantPick').hidden = true; $('loginView').hidden = false;
  say(msg);
}
function showTab(name) {
  document.querySelectorAll('.tab').forEach(s => { s.hidden = s.id !== `tab-${name}`; });
  document.querySelectorAll('#nav [data-tab]').forEach(b => b.classList.toggle('active', b.dataset.tab === name));
  ({ invoices: loadInvoices, wallet: loadWallet, keys: loadKeys, webhooks: loadWebhooks, admin: loadAdmin })[name]?.().catch(e => say(e.message, true));
}
const currentTab = () => document.querySelector('#nav .active')?.dataset.tab || 'invoices';

$('login').addEventListener('click', guard(async () => {
  say('Autenticando…');
  const data = await api('/auth/login', { method: 'POST', body: { email: $('email').value, password: $('password').value } });
  state.token = data.token; state.user = data.user; $('password').value = '';
  $('loginView').hidden = true; $('appView').hidden = false; $('nav').hidden = false;
  $('adminTab').hidden = data.user.role !== 'ADMIN';
  say(`Autenticado como ${data.user.email}`);
  await loadMerchants();
}));
$('logout').addEventListener('click', () => logout('Você saiu.'));
document.querySelectorAll('#nav [data-tab]').forEach(b => b.addEventListener('click', () => showTab(b.dataset.tab)));

async function loadMerchants(keep) {
  const { merchants } = state.user.role === 'ADMIN' ? await api('/merchants') : await api('/merchants/mine');
  state.merchants = merchants;
  const sel = $('merchantSelect'); sel.replaceChildren(...merchants.map(m => h('option', { value: m.id }, m.name)));
  $('merchantPick').hidden = !merchants.length;
  state.merchantId = (keep && merchants.some(m => m.id === keep)) ? keep : merchants[0]?.id || null;
  if (state.merchantId) sel.value = state.merchantId;
  else say(state.user.role === 'ADMIN' ? 'Nenhum comerciante ainda. Crie um na aba Admin.' : 'Sua conta ainda não está vinculada a um comerciante. Peça a um administrador.');
  showTab(state.merchantId ? currentTab() : (state.user.role === 'ADMIN' ? 'admin' : 'invoices'));
}
$('merchantSelect').addEventListener('change', (e) => { state.merchantId = e.target.value; showTab(currentTab()); });

// ---------- Cobranças ----------
async function loadInvoices() {
  const rows = $('invoiceRows'); rows.replaceChildren();
  if (!state.merchantId) return;
  const { invoices } = await api(`/invoices?merchantId=${encodeURIComponent(state.merchantId)}`);
  const paid = invoices.filter(i => ['CONFIRMED', 'OVERPAID'].includes(i.status));
  $('sTotal').textContent = invoices.length; $('sPaid').textContent = paid.length;
  $('sOpen').textContent = invoices.filter(i => ['PENDING', 'DETECTED', 'CONFIRMING'].includes(i.status)).length;
  $('sSats').textContent = paid.reduce((a, i) => a + BigInt(i.paidSats), 0n).toString();
  for (const i of invoices) {
    const actions = h('td', {}, h('a', { href: `/pay/${i.id}`, target: '_blank', rel: 'noopener' }, 'Abrir'));
    if (i.network === 'bitcoin-testnet' && ['PENDING', 'DETECTED', 'CONFIRMING'].includes(i.status)) {
      actions.append(' · ', h('a', { href: '#', onclick: guard(async (ev) => { ev.preventDefault(); await api(`/invoices/${i.id}/simulate-payment`, { method: 'POST', body: {} }); await loadInvoices(); }) }, 'Simular pgto'));
    }
    rows.append(h('tr', {}, h('td', {}, fmtDate(i.createdAt)), h('td', {}, i.description), h('td', {}, i.amountSats),
      h('td', {}, h('span', { class: `badge ${i.status.toLowerCase()}` }, i.status)), h('td', {}, `${i.confirmations}/${i.requiredConfirmations}`), actions));
  }
}
$('createInvoice').addEventListener('click', guard(async () => {
  const body = { amountSats: Number($('invAmount').value), description: $('invDesc').value };
  if ($('invRef').value.trim()) body.merchantReference = $('invRef').value.trim();
  const inv = await api(`/invoices/dashboard/${state.merchantId}`, { method: 'POST', body });
  say(`Cobrança criada. Endereço: ${inv.address}`);
  $('invAmount').value = ''; $('invDesc').value = ''; $('invRef').value = '';
  await loadInvoices();
}));

// ---------- Carteira ----------
async function loadWallet() {
  const { merchant } = await api(`/merchants/${state.merchantId}`);
  state.merchant = merchant;
  $('walletInfo').textContent = merchant.xpub ? `Rede: ${merchant.xpubNetwork} · próximos endereços a partir do índice ${merchant.nextAddressIndex} · ${merchant.xpub.slice(0, 12)}…${merchant.xpub.slice(-6)}` : 'Nenhuma carteira configurada — não é possível criar cobranças.';
  $('envNote').textContent = merchant.xpubNetwork === 'bitcoin-mainnet' ? 'MAINNET · fundos reais' : 'TESTNET · sem fundos reais';
}
$('saveWallet').addEventListener('click', guard(async () => {
  const r = await api(`/merchants/${state.merchantId}/wallet`, { method: 'PUT', body: { xpub: $('xpubInput').value.trim() } });
  $('xpubInput').value = '';
  say(`Carteira salva (${r.network}). Confira se o 1º endereço é o mesmo na sua carteira: ${r.firstAddress}`);
  await loadWallet();
}));

// ---------- API Keys ----------
async function loadKeys() {
  const rows = $('keyRows'); rows.replaceChildren();
  if (!state.merchantId) return;
  const { keys } = await api(`/merchants/${state.merchantId}/api-keys`);
  for (const k of keys) {
    rows.append(h('tr', {}, h('td', {}, k.name), h('td', { class: 'mono' }, k.prefix), h('td', {}, k.status), h('td', {}, fmtDate(k.lastUsedAt)),
      h('td', {}, k.status === 'ACTIVE' ? h('button', { class: 'small danger', onclick: guard(async () => { await api(`/merchants/${state.merchantId}/api-keys/${k.id}/revoke`, { method: 'POST' }); await loadKeys(); }) }, 'Revogar') : '')));
  }
}
$('createKey').addEventListener('click', guard(async () => {
  const r = await api(`/merchants/${state.merchantId}/api-keys`, { method: 'POST', body: { name: $('keyName').value } });
  $('secretBox').hidden = false; $('secretBox').textContent = `${r.secret}\n\n${r.warning}`; $('keyName').value = '';
  await loadKeys();
}));

// ---------- Webhooks ----------
async function loadWebhooks() {
  const rows = $('whRows'); rows.replaceChildren();
  if (!state.merchantId) return;
  const { webhooks } = await api(`/merchants/${state.merchantId}/webhooks`);
  for (const w of webhooks) {
    rows.append(h('tr', {}, h('td', { class: 'mono' }, w.url), h('td', {}, w.enabled ? 'sim' : 'não'),
      h('td', {}, h('button', { class: 'small danger', onclick: guard(async () => { await api(`/merchants/${state.merchantId}/webhooks/${w.id}`, { method: 'DELETE' }); await loadWebhooks(); }) }, 'Remover'))));
  }
}
$('createWebhook').addEventListener('click', guard(async () => {
  const r = await api(`/merchants/${state.merchantId}/webhooks`, { method: 'POST', body: { url: $('whUrl').value.trim() } });
  $('whSecretBox').hidden = false; $('whSecretBox').textContent = `${r.secret}\n\n${r.warning}`; $('whUrl').value = '';
  await loadWebhooks();
}));

// ---------- Admin ----------
async function loadAdmin() {
  const o = await api('/admin/overview');
  $('adminStats').textContent = `Usuários: ${o.counts.users} · Comerciantes: ${o.counts.merchants} · Cobranças: ${o.counts.invoices}`;
}
$('createMerchant').addEventListener('click', guard(async () => {
  const r = await api('/merchants', { method: 'POST', body: { name: $('newMerchant').value } });
  $('newMerchant').value = ''; say(`Comerciante "${r.merchant.name}" criado.`);
  await loadMerchants(r.merchant.id);
}));
$('addMember').addEventListener('click', guard(async () => {
  await api(`/merchants/${state.merchantId}/members`, { method: 'POST', body: { email: $('memberEmail').value, role: $('memberRole').value } });
  say('Usuário vinculado.'); $('memberEmail').value = '';
}));
