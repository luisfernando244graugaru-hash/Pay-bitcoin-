const id = location.pathname.split('/').pop();
const $ = (x) => document.getElementById(x);
const labels = { PENDING: 'Aguardando pagamento', DETECTED: 'Pagamento detectado', CONFIRMING: 'Confirmando…', CONFIRMED: 'Pagamento confirmado ✔', OVERPAID: 'Pago (valor acima do pedido) ✔', EXPIRED: 'Cobrança expirada', UNDERPAID: 'Pago a menos', FAILED: 'Falhou' };
let timer;
async function refresh() {
  try {
    const res = await fetch(`/api/v1/public/invoices/${encodeURIComponent(id)}`);
    if (!res.ok) { $('note').textContent = 'Cobrança não encontrada.'; clearInterval(timer); return; }
    const i = await res.json();
    $('merchant').textContent = i.merchant; $('desc').textContent = i.description;
    $('amount').textContent = `${i.amountBtc} BTC`;
    $('status').textContent = labels[i.status] || i.status; $('status').className = `badge ${i.status.toLowerCase()}`;
    $('confs').textContent = i.confirmations > 0 ? `${i.confirmations}/${i.requiredConfirmations} confirmações` : '';
    const open = ['PENDING', 'DETECTED', 'CONFIRMING'].includes(i.status);
    $('payBox').hidden = !open;
    if (open) {
      $('address').textContent = i.address; $('walletLink').href = i.paymentUri;
      $('expires').textContent = `Expira em ${new Date(i.expiresAt).toLocaleString('pt-BR')}` + (i.network === 'bitcoin-testnet' ? ' · TESTNET (moedas sem valor)' : '');
    }
    if (['CONFIRMED', 'OVERPAID', 'EXPIRED', 'FAILED'].includes(i.status)) clearInterval(timer);
  } catch { $('note').textContent = 'Sem conexão. Tentando novamente…'; }
}
$('copy').addEventListener('click', async () => { try { await navigator.clipboard.writeText($('address').textContent); $('note').textContent = 'Endereço copiado.'; } catch { $('note').textContent = 'Selecione e copie manualmente.'; } });
refresh(); timer = setInterval(refresh, 10_000);
