import { randomBytes } from 'node:crypto';
const hex = (n) => randomBytes(n).toString('hex');
console.log(`JWT_SECRET=${hex(32)}`);
console.log(`APP_ENCRYPTION_KEY=${hex(32)}`);
console.log(`REGISTRATION_INVITE_CODE=${hex(16)}`);
console.log(`ADMIN_BOOTSTRAP_PASSWORD=${randomBytes(18).toString('base64url')}`);
