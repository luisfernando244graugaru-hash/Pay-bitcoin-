# Produção — o que está pronto e o que falta

## Implementado (v0.4)
- Derivação de endereços BIP84 só com chave pública (verificada com os vetores oficiais do BIP84); rejeita xprv/zprv/vprv.
- Monitor de blockchain com confirmações configuráveis; estados PENDING → DETECTED → CONFIRMING → CONFIRMED/OVERPAID, EXPIRED, UNDERPAID.
- Criação de cobrança + endereço + idempotência em uma única transação, com lock por comerciante.
- Webhooks: HTTPS obrigatório, bloqueio de IP privado no momento da conexão (anti-DNS-rebinding), sem redirects, assinatura HMAC, retentativas com backoff, segredo cifrado (AES-256-GCM).
- Ledger idempotente; auditoria; chaves de API só como hash; login sem enumeração por tempo.

## Ainda NÃO implementado (obrigatório antes de dinheiro real)
- MFA/passkeys, e-mail verificado, recuperação de senha, revogação de sessão/refresh token.
- Rate limit distribuído (hoje em memória), WAF/DDoS na borda, TLS, segredos em cofre.
- Tratamento de reorg além da releitura periódica; taxa/RBF/pagamentos em várias transações são somados, sem política de reembolso.
- Dependência de API pública (mempool.space). Em produção use seu próprio nó/Esplora.
- Sem testes automatizados de integração com banco, sem pentest, sem auditoria independente.
- Sem QR Code na página de pagamento (há link `bitcoin:` e botão copiar).
- Aspectos legais/regulatórios (VASP, AML/KYC, LGPD) — consulte advogado.

## Gap limit
Cada cobrança usa um endereço novo. Cobranças expiradas sem pagamento deixam "buracos" na sequência; se passarem do gap limit da carteira, pagamentos tardios não aparecerão nela até ajustar o gap limit.
