import 'dotenv/config';
import bcrypt from 'bcryptjs';
import { prisma } from './lib/prisma.js';
const email = process.env.ADMIN_BOOTSTRAP_EMAIL?.toLowerCase();
const password = process.env.ADMIN_BOOTSTRAP_PASSWORD;
if (!email || !password || password.startsWith('REPLACE_') || password.length < 16) {
  console.error('Set ADMIN_BOOTSTRAP_EMAIL and a unique ADMIN_BOOTSTRAP_PASSWORD of at least 16 characters.');
  process.exit(1);
}
const passwordHash = await bcrypt.hash(password, Number(process.env.BCRYPT_ROUNDS || 12));
const user = await prisma.user.upsert({
  where: { email }, update: {},
  create: { email, passwordHash, role: 'ADMIN' }
});
console.log(`Admin account ready: ${user.email}`);
await prisma.$disconnect();
