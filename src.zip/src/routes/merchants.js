import { Router } from 'express';
import { z } from 'zod';
import { prisma } from '../lib/prisma.js';
import { audit } from '../lib/audit.js';
import { createApiKey, hashSecret } from '../lib/crypto.js';
import { requireAuth, requireRole } from '../middleware/security.js';
import { hasMerchantAccess } from '../lib/access.js';
import { deriveAddress } from '../lib/bitcoin.js';
import { validateWebhookUrl } from '../lib/net-safety.js';
import { encryptSecret } from '../lib/secrets.js';
import { randomBytes } from 'node:crypto';

const router = Router();
router.use(requireAuth);

router.post('/', requireRole('ADMIN'), async (req, res, next) => {
  try {
    const parsed = z.object({ name: z.string().trim().min(2).max(120), legalName: z.string().max(180).optional(), taxId: z.string().max(32).optional() }).safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: 'invalid_request' });
    const merchant = await prisma.merchant.create({
      data: { ...parsed.data, members: { create: { userId: req.user.id, role: 'OWNER' } } }
    });
    await audit({ actorId: req.user.id, action: 'merchant.created', subject: merchant.id });
    res.status(201).json({ merchant });
  } catch (err) { next(err); }
});
router.get('/mine', async (req, res, next) => {
  try {
    const rows = await prisma.merchantMember.findMany({
      where: { userId: req.user.id }, include: { merchant: true }
    });
    res.json({ merchants: rows.map(x => ({ ...x.merchant, membershipRole: x.role })) });
  } catch (err) { next(err); }
});
router.get('/', requireRole('ADMIN'), async (_req, res, next) => {
  try { res.json({ merchants: await prisma.merchant.findMany({ take: 100, orderBy: { createdAt: 'desc' } }) }); }
  catch (err) { next(err); }
});
router.post('/:merchantId/api-keys', async (req, res, next) => {
  try {
    const membership = await prisma.merchantMember.findFirst({
      where: { merchantId: req.params.merchantId, userId: req.user.id, role: { in: ['OWNER', 'ADMIN'] } }
    });
    if (!membership && req.user.role !== 'ADMIN') return res.status(404).json({ error: 'merchant_not_found' });
    const parsed = z.object({ name: z.string().trim().min(2).max(80) }).safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: 'invalid_request' });
    const generated = createApiKey();
    const key = await prisma.apiKey.create({
      data: { merchantId: req.params.merchantId, name: parsed.data.name, prefix: generated.prefix, keyHash: hashSecret(generated.raw) },
      select: { id: true, name: true, prefix: true, createdAt: true }
    });
    await audit({ actorId: req.user.id, action: 'api_key.created', subject: key.id, metadata: { merchantId: req.params.merchantId } });
    res.status(201).json({ key, secret: generated.raw, warning: 'Copy this secret now. It cannot be displayed again.' });
  } catch (err) { next(err); }
});
router.get('/:merchantId/api-keys', async (req, res, next) => {
  try {
    const membership = await prisma.merchantMember.findFirst({
      where: { merchantId: req.params.merchantId, userId: req.user.id }
    });
    if (!membership && req.user.role !== 'ADMIN') return res.status(404).json({ error: 'merchant_not_found' });
    const keys = await prisma.apiKey.findMany({
      where: { merchantId: req.params.merchantId },
      select: { id: true, name: true, prefix: true, status: true, lastUsedAt: true, createdAt: true, revokedAt: true }
    });
    res.json({ keys });
  } catch (err) { next(err); }
});
router.post('/:merchantId/api-keys/:keyId/revoke', async (req, res, next) => {
  try {
    const membership = await prisma.merchantMember.findFirst({
      where: { merchantId: req.params.merchantId, userId: req.user.id, role: { in: ['OWNER', 'ADMIN'] } }
    });
    if (!membership && req.user.role !== 'ADMIN') return res.status(404).json({ error: 'merchant_not_found' });
    const result = await prisma.apiKey.updateMany({
      where: { id: req.params.keyId, merchantId: req.params.merchantId, status: 'ACTIVE' },
      data: { status: 'REVOKED', revokedAt: new Date() }
    });
    if (!result.count) return res.status(404).json({ error: 'api_key_not_found' });
    await audit({ actorId: req.user.id, action: 'api_key.revoked', subject: req.params.keyId });
    res.json({ revoked: true });
  } catch (err) { next(err); }
});

const OWNER_ADMIN = ['OWNER', 'ADMIN'];
const notFound = (res) => res.status(404).json({ error: 'merchant_not_found' });

// Dados do comerciante (inclui xpub, que é público por natureza)
router.get('/:merchantId', async (req, res, next) => {
  try {
    if (!(await hasMerchantAccess(req.user, req.params.merchantId))) return notFound(res);
    const m = await prisma.merchant.findUnique({ where: { id: req.params.merchantId } });
    res.json({ merchant: m });
  } catch (err) { next(err); }
});

// Configura a carteira NÃO-CUSTODIAL (zpub mainnet / vpub testnet). Chaves privadas são rejeitadas.
router.put('/:merchantId/wallet', async (req, res, next) => {
  try {
    if (!(await hasMerchantAccess(req.user, req.params.merchantId, OWNER_ADMIN))) return notFound(res);
    const parsed = z.object({ xpub: z.string().trim().min(100).max(130) }).safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: 'invalid_request' });
    let derived;
    try { derived = deriveAddress(parsed.data.xpub, 0); }
    catch (e) { return res.status(400).json({ error: e.message }); }
    if (derived.network === 'bitcoin-mainnet' && process.env.ALLOW_MAINNET !== 'true') {
      return res.status(403).json({ error: 'mainnet_disabled', hint: 'Defina ALLOW_MAINNET=true no .env quando estiver pronto.' });
    }
    const merchant = await prisma.merchant.update({
      where: { id: req.params.merchantId },
      data: { xpub: parsed.data.xpub, xpubNetwork: derived.network, nextAddressIndex: 0 }
    });
    await audit({ actorId: req.user.id, action: 'merchant.wallet_set', subject: merchant.id, metadata: { network: derived.network } });
    res.json({ network: derived.network, firstAddress: derived.address });
  } catch (err) { next(err); }
});

// Admin vincula um usuário a um comerciante
router.post('/:merchantId/members', requireRole('ADMIN'), async (req, res, next) => {
  try {
    const parsed = z.object({ email: z.string().email().transform(v => v.toLowerCase()), role: z.enum(['OWNER', 'ADMIN', 'DEVELOPER', 'VIEWER']).default('VIEWER') }).safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: 'invalid_request' });
    const user = await prisma.user.findUnique({ where: { email: parsed.data.email } });
    if (!user) return res.status(404).json({ error: 'user_not_found' });
    const member = await prisma.merchantMember.upsert({
      where: { merchantId_userId: { merchantId: req.params.merchantId, userId: user.id } },
      update: { role: parsed.data.role }, create: { merchantId: req.params.merchantId, userId: user.id, role: parsed.data.role }
    });
    await audit({ actorId: req.user.id, action: 'merchant.member_set', subject: req.params.merchantId, metadata: { userId: user.id, role: member.role } });
    res.status(201).json({ member: { userId: user.id, role: member.role } });
  } catch (err) {
    if (err.code === 'P2003') return notFound(res);
    next(err);
  }
});

// ---- Webhooks ----
router.get('/:merchantId/webhooks', async (req, res, next) => {
  try {
    if (!(await hasMerchantAccess(req.user, req.params.merchantId))) return notFound(res);
    const rows = await prisma.webhookEndpoint.findMany({ where: { merchantId: req.params.merchantId }, orderBy: { createdAt: 'desc' }, select: { id: true, url: true, enabled: true, createdAt: true } });
    res.json({ webhooks: rows });
  } catch (err) { next(err); }
});
router.post('/:merchantId/webhooks', async (req, res, next) => {
  try {
    if (!(await hasMerchantAccess(req.user, req.params.merchantId, OWNER_ADMIN))) return notFound(res);
    const parsed = z.object({ url: z.string().url().max(500) }).safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: 'invalid_request' });
    try { validateWebhookUrl(parsed.data.url, { allowInsecure: process.env.ALLOW_INSECURE_WEBHOOKS === 'true' && process.env.NODE_ENV !== 'production' }); }
    catch (e) { return res.status(400).json({ error: e.message }); }
    const count = await prisma.webhookEndpoint.count({ where: { merchantId: req.params.merchantId } });
    if (count >= 5) return res.status(409).json({ error: 'webhook_limit_reached' });
    const secret = `whsec_${randomBytes(32).toString('base64url')}`;
    const wh = await prisma.webhookEndpoint.create({
      data: { merchantId: req.params.merchantId, url: parsed.data.url, secretEnc: encryptSecret(secret) },
      select: { id: true, url: true, enabled: true, createdAt: true }
    });
    await audit({ actorId: req.user.id, action: 'webhook.created', subject: wh.id });
    res.status(201).json({ webhook: wh, secret, warning: 'Guarde este segredo agora. Ele não será exibido novamente.' });
  } catch (err) { next(err); }
});
router.delete('/:merchantId/webhooks/:id', async (req, res, next) => {
  try {
    if (!(await hasMerchantAccess(req.user, req.params.merchantId, OWNER_ADMIN))) return notFound(res);
    const r = await prisma.webhookEndpoint.deleteMany({ where: { id: req.params.id, merchantId: req.params.merchantId } });
    if (!r.count) return res.status(404).json({ error: 'webhook_not_found' });
    await audit({ actorId: req.user.id, action: 'webhook.deleted', subject: req.params.id });
    res.json({ deleted: true });
  } catch (err) { next(err); }
});
export default router;
