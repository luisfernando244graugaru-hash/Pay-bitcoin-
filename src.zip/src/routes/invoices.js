import { Router } from 'express';
import { z } from 'zod';
import { randomUUID } from 'node:crypto';
import { prisma } from '../lib/prisma.js';
import { requireApiKey, requireAuth } from '../middleware/security.js';
import { hasMerchantAccess } from '../lib/access.js';
import { createInvoice, serializeInvoice, applyObservation, requiredConfirmations } from '../lib/invoice-service.js';

const router = Router();
export const invoiceSchema = z.object({
  amountSats: z.number().int().min(546).max(2100000000000000), // 546 = limite "dust" p2wpkh ~294; usamos 546 por segurança
  description: z.string().trim().min(1).max(240),
  merchantReference: z.string().trim().min(1).max(100).optional(),
  expiresInMinutes: z.number().int().min(5).max(1440).optional()
});

export async function handleCreate(req, res, next, merchantId, idemKey) {
  try {
    const parsed = invoiceSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: 'invalid_request', details: parsed.error.flatten() });
    if (!idemKey || idemKey.length < 8 || idemKey.length > 128) return res.status(400).json({ error: 'idempotency_key_required' });
    const { replay, response } = await createInvoice(merchantId, parsed.data, idemKey);
    res.status(replay ? 200 : 201).json(response);
  } catch (err) {
    if (err.http) return res.status(err.http).json({ error: err.message });
    if (err.code === 'P2002') return res.status(409).json({ error: 'duplicate_merchant_reference' });
    next(err);
  }
}

// Integração servidor-a-servidor (API key)
router.post('/', requireApiKey, (req, res, next) => handleCreate(req, res, next, req.apiKey.merchantId, req.get('Idempotency-Key')));

router.get('/:id', requireApiKey, async (req, res, next) => {
  try {
    const inv = await prisma.invoice.findFirst({ where: { id: req.params.id, merchantId: req.apiKey.merchantId } });
    if (!inv) return res.status(404).json({ error: 'invoice_not_found' });
    res.json(serializeInvoice(inv));
  } catch (err) { next(err); }
});

// Painel (JWT)
router.get('/', requireAuth, async (req, res, next) => {
  try {
    const merchantId = req.query.merchantId;
    if (typeof merchantId !== 'string') return res.status(400).json({ error: 'merchant_id_required' });
    if (!(await hasMerchantAccess(req.user, merchantId))) return res.status(404).json({ error: 'merchant_not_found' });
    const rows = await prisma.invoice.findMany({ where: { merchantId }, orderBy: { createdAt: 'desc' }, take: 100 });
    res.json({ invoices: rows.map(serializeInvoice) });
  } catch (err) { next(err); }
});

router.post('/dashboard/:merchantId', requireAuth, async (req, res, next) => {
  try {
    if (!(await hasMerchantAccess(req.user, req.params.merchantId, ['OWNER', 'ADMIN', 'DEVELOPER']))) return res.status(404).json({ error: 'merchant_not_found' });
    await handleCreate(req, res, next, req.params.merchantId, req.get('Idempotency-Key') || `dash-${randomUUID()}`);
  } catch (err) { next(err); }
});

// Simulação de pagamento: SOMENTE desenvolvimento e SOMENTE testnet.
router.post('/:id/simulate-payment', requireAuth, async (req, res, next) => {
  try {
    if (process.env.ENABLE_DEV_SIMULATION !== 'true' || process.env.NODE_ENV === 'production') return res.status(404).json({ error: 'not_found' });
    const inv = await prisma.invoice.findUnique({ where: { id: req.params.id } });
    if (!inv || !(await hasMerchantAccess(req.user, inv.merchantId, ['OWNER', 'ADMIN', 'DEVELOPER']))) return res.status(404).json({ error: 'invoice_not_found' });
    if (inv.network !== 'bitcoin-testnet') return res.status(403).json({ error: 'simulation_testnet_only' });
    const p = z.object({ confirmations: z.number().int().min(0).max(10).default(requiredConfirmations()), amountSats: z.number().int().positive().optional() }).safeParse(req.body || {});
    if (!p.success) return res.status(400).json({ error: 'invalid_request' });
    const sats = BigInt(p.data.amountSats ?? inv.amountSats);
    const confirmed = p.data.confirmations >= requiredConfirmations() ? sats : 0n;
    const updated = await applyObservation(inv.id, {
      total: sats, confirmedTotal: confirmed, maxConfirmations: p.data.confirmations,
      txid: inv.txid || `sim${randomUUID().replaceAll('-', '')}${randomUUID().replaceAll('-', '')}`.slice(0, 64)
    });
    res.json(serializeInvoice(updated));
  } catch (err) { next(err); }
});
export default router;
