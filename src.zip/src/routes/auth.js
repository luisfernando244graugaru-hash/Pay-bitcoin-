import { Router } from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { z } from 'zod';
import { prisma } from '../lib/prisma.js';
import { audit } from '../lib/audit.js';
import { authLimiter, requireAuth } from '../middleware/security.js';

const router = Router();
// hash falso para manter o tempo de resposta igual quando o e-mail não existe (evita enumeração de usuários)
const DUMMY_HASH = bcrypt.hashSync('dummy-password-for-timing', 10);
router.use(authLimiter);
const credentials = z.object({
  email: z.string().email().max(254).transform(v => v.toLowerCase()),
  password: z.string().min(12).max(128)
});
function issueToken(user) {
  return jwt.sign({}, process.env.JWT_SECRET, {
    subject: user.id, issuer: process.env.JWT_ISSUER, audience: process.env.JWT_AUDIENCE,
    algorithm: 'HS256', expiresIn: process.env.JWT_EXPIRES_IN || '10m'
  });
}
router.post('/register', async (req, res, next) => {
  try {
    if (process.env.REGISTRATION_ENABLED !== 'true') return res.status(403).json({ error: 'registration_closed' });
    const parsed = credentials.extend({ inviteCode: z.string().min(24).max(256) }).safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: 'invalid_request' });
    if (parsed.data.inviteCode !== process.env.REGISTRATION_INVITE_CODE) return res.status(403).json({ error: 'invalid_invitation' });
    const passwordHash = await bcrypt.hash(parsed.data.password, Number(process.env.BCRYPT_ROUNDS || 12));
    const user = await prisma.user.create({
      data: { email: parsed.data.email, passwordHash, role: 'MERCHANT' },
      select: { id: true, email: true, role: true }
    });
    await audit({ actorId: user.id, action: 'user.registered', subject: user.id });
    res.status(201).json({ user, token: issueToken(user) });
  } catch (err) {
    if (err.code === 'P2002') return res.status(409).json({ error: 'account_unavailable' });
    next(err);
  }
});
router.post('/login', async (req, res, next) => {
  try {
    const parsed = credentials.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: 'invalid_request' });
    const user = await prisma.user.findUnique({ where: { email: parsed.data.email } });
    const match = await bcrypt.compare(parsed.data.password, user?.passwordHash || DUMMY_HASH);
    const valid = !!user && user.active && match;
    if (!valid) {
      await audit({ action: 'auth.login_failed', subject: parsed.data.email, metadata: { requestId: req.requestId } });
      return res.status(401).json({ error: 'invalid_credentials' });
    }
    await audit({ actorId: user.id, action: 'auth.login_succeeded', subject: user.id });
    res.json({ user: { id: user.id, email: user.email, role: user.role }, token: issueToken(user) });
  } catch (err) { next(err); }
});
router.get('/me', requireAuth, (req, res) => res.json({ user: req.user }));
export default router;
