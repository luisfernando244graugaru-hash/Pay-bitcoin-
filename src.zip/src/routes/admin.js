import { Router } from 'express';
import { prisma } from '../lib/prisma.js';
import { requireAuth, requireRole } from '../middleware/security.js';
const router = Router();
router.use(requireAuth, requireRole('ADMIN'));
router.get('/overview', async (_req, res, next) => {
  try {
    const [users, merchants, invoices, recentEvents] = await Promise.all([
      prisma.user.count(), prisma.merchant.count(), prisma.invoice.count(),
      prisma.auditEvent.findMany({ orderBy: { createdAt: 'desc' }, take: 20,
        select: { id: true, actorId: true, action: true, subject: true, createdAt: true } })
    ]);
    res.json({ counts: { users, merchants, invoices }, recentEvents });
  } catch (err) { next(err); }
});
router.get('/users', async (_req, res, next) => {
  try {
    res.json({ users: await prisma.user.findMany({ take: 100, orderBy: { createdAt: 'desc' },
      select: { id: true, email: true, role: true, active: true, createdAt: true } }) });
  } catch (err) { next(err); }
});
export default router;
