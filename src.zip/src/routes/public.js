import { Router } from 'express';
import rateLimit from 'express-rate-limit';
import { prisma } from '../lib/prisma.js';
import { serializeInvoice } from '../lib/invoice-service.js';

const router = Router();
router.use(rateLimit({ windowMs: 60_000, limit: 60, standardHeaders: 'draft-7', legacyHeaders: false, message: { error: 'rate_limit_exceeded' } }));
// Página de pagamento: devolve só o necessário para o cliente pagar.
router.get('/invoices/:id', async (req, res, next) => {
  try {
    const inv = await prisma.invoice.findUnique({ where: { id: req.params.id }, include: { merchant: { select: { name: true } } } });
    if (!inv) return res.status(404).json({ error: 'invoice_not_found' });
    const s = serializeInvoice(inv);
    res.json({
      merchant: inv.merchant.name, id: s.id, status: s.status, network: s.network, amountSats: s.amountSats, amountBtc: s.amountBtc,
      paidSats: s.paidSats, address: s.address, paymentUri: s.paymentUri, description: s.description,
      confirmations: s.confirmations, requiredConfirmations: s.requiredConfirmations, expiresAt: s.expiresAt
    });
  } catch (err) { next(err); }
});
export default router;
