import 'dotenv/config';
import express from 'express';
import helmet from 'helmet';
import cors from 'cors';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import authRoutes from './routes/auth.js';
import invoiceRoutes from './routes/invoices.js';
import merchantRoutes from './routes/merchants.js';
import adminRoutes from './routes/admin.js';
import publicRoutes from './routes/public.js';
import { startWatcher } from './lib/invoice-service.js';
import { startWebhookWorker } from './lib/webhooks.js';
import { generalLimiter, requestContext } from './middleware/security.js';
import { prisma } from './lib/prisma.js';

if (!process.env.JWT_SECRET || process.env.JWT_SECRET.length < 32 || process.env.JWT_SECRET.startsWith('REPLACE_')) {
  throw new Error('JWT_SECRET must be a unique secret with at least 32 characters.');
}
if (!process.env.DATABASE_URL) throw new Error('DATABASE_URL is required.');
if (process.env.NODE_ENV === 'production' && process.env.ENABLE_DEV_SIMULATION === 'true') {
  throw new Error('Development simulation must be disabled in production.');
}
const isProd = process.env.NODE_ENV === 'production';
const app = express();
const dirname = path.dirname(fileURLToPath(import.meta.url));
app.disable('x-powered-by');
app.set('trust proxy', Number(process.env.TRUST_PROXY_HOPS || 0));
app.use(requestContext);
app.use(helmet({
  contentSecurityPolicy: { directives: {
    defaultSrc: ["'self'"], scriptSrc: ["'self'"], styleSrc: ["'self'"],
    imgSrc: ["'self'", 'data:'], connectSrc: ["'self'"],
    frameAncestors: ["'none'"], baseUri: ["'none'"], formAction: ["'self'"],
    upgradeInsecureRequests: isProd ? [] : null // em http://localhost isso quebraria o carregamento dos arquivos
  }},
  strictTransportSecurity: isProd,
  referrerPolicy: { policy: 'no-referrer' }
}));
const allowedOrigins = (process.env.CORS_ORIGINS || '').split(',').map(x => x.trim()).filter(Boolean);
try { if (process.env.APP_BASE_URL) allowedOrigins.push(new URL(process.env.APP_BASE_URL).origin); } catch { /* ignora */ }
app.use(cors({
  origin(origin, cb) { if (!origin || allowedOrigins.includes(origin)) return cb(null, true); cb(new Error('origin_not_allowed')); },
  methods: ['GET', 'POST', 'PATCH', 'DELETE'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-API-Key', 'Idempotency-Key'],
  credentials: false, maxAge: 600
}));
app.use(express.json({ limit: '16kb', strict: true }));
app.use(generalLimiter);
app.use(express.static(path.join(dirname, '../public'), { index: 'index.html', maxAge: '1h' }));
app.get('/health/live', (_req, res) => res.json({ ok: true }));
app.get('/health/ready', async (_req, res) => {
  try { await prisma.$queryRaw`SELECT 1`; res.json({ ok: true, database: 'up' }); }
  catch { res.status(503).json({ ok: false, database: 'down' }); }
});
app.get('/pay/:id', (_req, res) => res.sendFile(path.join(dirname, '../public/checkout.html')));
app.use('/api/v1/public', publicRoutes);
app.use('/api/v1/auth', authRoutes);
app.use('/api/v1/invoices', invoiceRoutes);
app.use('/api/v1/merchants', merchantRoutes);
app.use('/api/v1/admin', adminRoutes);
app.use('/api', (_req, res) => res.status(404).json({ error: 'not_found' }));
app.use((err, req, res, _next) => {
  let status = 500, code = 'internal_error';
  if (err.message === 'origin_not_allowed') { status = 403; code = 'origin_not_allowed'; }
  else if (err.type === 'entity.parse.failed') { status = 400; code = 'invalid_json'; }
  else if (err.type === 'entity.too.large') { status = 413; code = 'payload_too_large'; }
  if (status === 500) console.error(JSON.stringify({ event: 'request_error', requestId: req.requestId, message: err.message }));
  res.status(status).json({ error: code, requestId: req.requestId });
});
let stopWatcher = () => {}, stopWebhooks = () => {};
const server = app.listen(Number(process.env.PORT || 3000), () => {
  console.log(`DEAD DIGITAL PAY v0.4 listening on :${process.env.PORT || 3000}`);
  stopWatcher = startWatcher();
  stopWebhooks = startWebhookWorker();
});
async function shutdown(signal) {
  console.log(`${signal} received`);
  stopWatcher(); stopWebhooks();
  server.close(async () => { await prisma.$disconnect(); process.exit(0); });
  setTimeout(() => process.exit(1), 10000).unref();
}
process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));
