import { randomUUID } from 'node:crypto';
import rateLimit from 'express-rate-limit';
import jwt from 'jsonwebtoken';
import { prisma } from '../lib/prisma.js';
import { hashSecret } from '../lib/crypto.js';

export const requestContext = (req, res, next) => {
  req.requestId = randomUUID();
  res.setHeader('X-Request-Id', req.requestId);
  res.setHeader('Cache-Control', 'no-store');
  next();
};
export const generalLimiter = rateLimit({
  windowMs: 60_000, limit: 100, standardHeaders: 'draft-7',
  legacyHeaders: false, message: { error: 'rate_limit_exceeded' }
});
export const authLimiter = rateLimit({
  windowMs: 15 * 60_000, limit: 8, standardHeaders: 'draft-7',
  legacyHeaders: false, skipSuccessfulRequests: true,
  message: { error: 'too_many_auth_attempts' }
});
export async function requireAuth(req, res, next) {
  try {
    const [scheme, token] = (req.get('authorization') || '').split(' ');
    if (scheme !== 'Bearer' || !token) return res.status(401).json({ error: 'unauthorized' });
    const payload = jwt.verify(token, process.env.JWT_SECRET, {
      issuer: process.env.JWT_ISSUER, audience: process.env.JWT_AUDIENCE,
      algorithms: ['HS256']
    });
    const user = await prisma.user.findUnique({
      where: { id: payload.sub },
      select: { id: true, email: true, role: true, active: true }
    });
    if (!user?.active) return res.status(401).json({ error: 'unauthorized' });
    req.user = user;
    next();
  } catch { return res.status(401).json({ error: 'unauthorized' }); }
}
export const requireRole = (...roles) => (req, res, next) => {
  if (!req.user || !roles.includes(req.user.role)) return res.status(403).json({ error: 'forbidden' });
  next();
};
export async function requireApiKey(req, res, next) {
  try {
    const raw = req.get('x-api-key');
    if (!raw || !raw.startsWith('ddp_live_')) return res.status(401).json({ error: 'invalid_api_key' });
    const key = await prisma.apiKey.findUnique({
      where: { keyHash: hashSecret(raw) },
      include: { merchant: { select: { id: true, name: true } } }
    });
    if (!key || key.status !== 'ACTIVE') return res.status(401).json({ error: 'invalid_api_key' });
    req.apiKey = { id: key.id, merchantId: key.merchantId, merchant: key.merchant };
    await prisma.apiKey.update({ where: { id: key.id }, data: { lastUsedAt: new Date() } });
    next();
  } catch { return res.status(401).json({ error: 'invalid_api_key' }); }
}
